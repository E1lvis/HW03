package com.example.hw03;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link BACCalculatorFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class BACCalculatorFragment extends Fragment {

    public double calculateBAC(Integer w, ArrayList<Drink> drinks, String gender){
        Double A = 0.00;
        Double calculatedValue = 0.00;

        for(Drink currentDrink: drinks){

            A +=  (Double.valueOf(currentDrink.getDrinkSizeOz()) * Double.valueOf(currentDrink.getAlcoholContent()) / 100);
        }

        switch (gender){
            case "(Female)":
                calculatedValue = A*5.14 / (currentProfile.getWieght()*.66);


                break;
            case "(Male)":
                calculatedValue = A*5.14 / (currentProfile.getWieght()*.73);


                break;


        }

        return calculatedValue;

    }

    public void checkStatus(TextView status, Double bac){
        if(bac > 0.2){
            status.setText("Over the limit!");
            status.setBackgroundColor(Color.parseColor("#c90606"));
        }else if(bac <= 0.2 && bac >= 0.08){
            status.setText("Be careful");
            status.setBackgroundColor(Color.parseColor("#cf6215"));
        }
    }

    ArrayList<Drink> dr;

    Integer weight = 0;
    String gender = "";
    Double currentBAC = 0.00;
    String df = new DecimalFormat("0.000").format(currentBAC);

    TextView drinkNumber;
    TextView bacLevelNumber;
    TextView status;
    TextView enteredTextView;

    Button viewDrinks;
    Button mainAddDrink;


    //variable to hold vurent user info
    Profile currentProfile;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;




    public BACCalculatorFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment BACCalculatorFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static BACCalculatorFragment newInstance(String param1, String param2) {
        BACCalculatorFragment fragment = new BACCalculatorFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_b_a_c_calculator, container, false);

         drinkNumber = view.findViewById(R.id.textViewDrinksNumber);
         bacLevelNumber = view.findViewById(R.id.textViewBACLevelNumber);
         status = view.findViewById(R.id.textViewStatusResult);
         enteredTextView = view.findViewById(R.id.textViewWeightInput);

        //Buttons
        Button resetButton = view.findViewById(R.id.buttonResetMain);
        Button mainSetButton = view.findViewById(R.id.buttonMainSet);
         viewDrinks = view.findViewById(R.id.buttonViewDrinks);
         mainAddDrink = view.findViewById(R.id.buttonMainAddDrink);

        //view drinks and add drinks button start off disabled
        mainAddDrink.setEnabled(false);
        viewDrinks.setEnabled(false);

        mainSetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.mainContainer, MainActivity.setProfilefrag, "setProfileFrag")
                        .addToBackStack(null)
                        .commit();


            }
        });

        //View drinks button functionality
        viewDrinks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(MainActivity.drinksCheck()){
                    Toast.makeText(getActivity(), "You have no drinks.", Toast.LENGTH_SHORT).show();

                }else{
                    getActivity().getSupportFragmentManager().beginTransaction()
                            .replace(R.id.mainContainer, MainActivity.viewDrinksFrag, "viewDrinksFragment")
                            .addToBackStack(null)
                            .commit();

                }
            }
        });


        //addDrink button functionality
        mainAddDrink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.mainContainer, MainActivity.addDrinkFrag, "addDrinksFragment")
                        .addToBackStack(null)
                        .commit();

            }
        });
        return view;
    }

    public void update(Profile p){
        currentProfile = p;




    }

    public void drinksChange(ArrayList<Drink> d){
        dr = d;
    }

    public void updateScreen(){
        //here if a profile has been passed in, onm resume we want to update that
        if(currentProfile != null){
            String s = String.format(String.valueOf(currentProfile.getWieght()) + " lbs " + currentProfile.getGender());
            enteredTextView.setText(s);
        }



        drinkNumber.setText("0");
        bacLevelNumber.setText("0.000");
        mainAddDrink.setEnabled(true);
        viewDrinks.setEnabled(true);

    }

    @Override
    public void onResume() {
        super.onResume();
        updateScreen();


        //dr is local drinks array taken from main activity
        //also we dont have to worry about a null excpetion here as dr will always
        //be null since you cant add a drink without making a profile first
        if(dr != null){
            if(!dr.isEmpty()){
                drinkNumber.setText(String.valueOf(dr.size()));

                currentBAC = calculateBAC(currentProfile.getWieght(), dr, currentProfile.getGender());
                df = new DecimalFormat("0.000").format(currentBAC);
                //bacLevelNumber.setText(String.valueOf(currentBAC));
                bacLevelNumber.setText(df);
                checkStatus(status, currentBAC);


            }


        }

        if(currentBAC >= 0.25){
            mainAddDrink.setEnabled(false);
            Toast.makeText(getActivity(), "No more drinks for you.", Toast.LENGTH_SHORT).show();
        }

    }


}