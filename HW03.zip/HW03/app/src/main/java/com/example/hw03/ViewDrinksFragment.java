package com.example.hw03;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ViewDrinksFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ViewDrinksFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM3 = "param1";
    int drinkIndex = 0;



    // TODO: Rename and change types of parameters
    private ArrayList<Drink> drinks;

    public ViewDrinksFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param dr
     * @return A new instance of fragment ViewDrinksFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ViewDrinksFragment newInstance(ArrayList<Drink> dr) {
        ViewDrinksFragment fragment = new ViewDrinksFragment();
        Bundle args = new Bundle();
        args.putParcelableArrayList(ARG_PARAM3, dr);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            drinks = getArguments().getParcelableArrayList(ARG_PARAM3);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_view_drinks, container, false);

        // get drinks from the main activity
        d.drinksFromMain();

        // buttons
        ImageButton back = view.findViewById(R.id.drinksBack);
        ImageButton forward = view.findViewById(R.id.drinksForward);
        ImageButton delete = view.findViewById(R.id.deleteDrink);
        Button close = view.findViewById(R.id.closeViewDrinks);

        // textviews
        TextView currentDrink = view.findViewById(R.id.currentDrink);
        TextView amountDrinks = view.findViewById(R.id.amountDrinks);
        TextView drinkSize = view.findViewById(R.id.drinkSize);
        TextView alcoholContent = view.findViewById(R.id.alcoholContent);
        TextView dateTime = view.findViewById(R.id.dateTime);


        // date
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        // setup for clicking through list
        // start at beginning of list
        amountDrinks.setText(String.valueOf(drinks.size()));
        currentDrink.setText(String.valueOf(drinkIndex + 1));
        drinkSize.setText(String.valueOf(drinks.get(0).getDrinkSizeOz()));
        alcoholContent.setText(String.valueOf(drinks.get(0).getAlcoholContent()));
        dateTime.setText(drinks.get(0).getDateTime());

        // back button for drinks list
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // edge case, first drink
                if (drinkIndex <= 0) {
                    // pressing back should return the last item in the list
                    drinkIndex = drinks.size() - 1;

                } else {
                    // not at the first drink, can go back
                    drinkIndex -= 1;

                }

                // display info to user
                currentDrink.setText(String.valueOf(drinkIndex + 1));
                alcoholContent.setText(String.valueOf(drinks.get(drinkIndex).getAlcoholContent()));
                drinkSize.setText(String.valueOf(drinks.get(drinkIndex).getDrinkSizeOz()));
                dateTime.setText(drinks.get(0).getDateTime());
            }
        });
        // forward btn for drinks list
        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // edge case, last drink
                if (drinkIndex >= drinks.size() - 1){
                    // pressing forward should return first drink in list
                    drinkIndex = 0;
                } else {
                    // not last drink, can go forward
                    drinkIndex += 1;
                }

                // display drink info to user
                currentDrink.setText(String.valueOf(drinkIndex + 1));
                alcoholContent.setText(String.valueOf(drinks.get(drinkIndex).getAlcoholContent()));
                drinkSize.setText(String.valueOf(drinks.get(drinkIndex).getDrinkSizeOz()));
                dateTime.setText(drinks.get(0).getDateTime());
            }
        });

        // trash icon button for drinks list
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!drinks.isEmpty()){
                    // edge case, removing last drink
                    if (drinkIndex <= 0 && drinks.size() == 1) {
                        drinks.remove(0);
                        // send drinks to main using interface
                        d.drinksToMain(drinks);
                        return;
                    }

                    // edge case, removing first drink
                    else if (drinkIndex == 0 ){
                        // remove drink from list
                        drinks.remove(0);
                        drinkIndex = drinks.size() - 1;
                    } else{
                        drinkIndex -= 1;
                        // remove drink from list
                        drinks.remove(drinkIndex);
                    }

                    if (!drinks.isEmpty()) {
                        amountDrinks.setText(String.valueOf(drinks.size()));
                        currentDrink.setText(String.valueOf(drinkIndex + 1));
                        alcoholContent.setText(String.valueOf(drinks.get(drinkIndex).getAlcoholContent()));
                        drinkSize.setText(String.valueOf(drinks.get(drinkIndex).getDrinkSizeOz()));
                        dateTime.setText(drinks.get(0).getDateTime());
                    }
                } else {
                    Toast.makeText(getActivity(), "You have no more drinks to delete", Toast.LENGTH_SHORT).show();
                }
            }
        });

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d.drinksToMain(drinks);

                getActivity().getSupportFragmentManager().popBackStack();
            }
        });

        return view;

    }



    public void passDrinks(ArrayList<Drink> drinksList){
        // set drinks field to drinks from main activity
        drinks = drinksList;
    }


    drinks_main_communicator d;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof ViewDrinksFragment.drinks_main_communicator){
            d = (ViewDrinksFragment.drinks_main_communicator) context;
        }
    }

    // used to communicate with main activity and get or send data
    public interface drinks_main_communicator{

        void drinksFromMain();
        void drinksToMain(ArrayList<Drink> drinkList);
    }
}