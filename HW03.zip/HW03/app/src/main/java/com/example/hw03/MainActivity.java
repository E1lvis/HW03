//Homework 3
//HW03
//Eduardo Gomez, Elvis Velasquez

package com.example.hw03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AddDrinkFragment.drinkMade, SetProfileFragment.profileListener {

    public static ArrayList<Drink> drinks = new ArrayList<>();

    public static BACCalculatorFragment mainFrag;
    public static ViewDrinksFragment viewDrinksFrag;
    public static AddDrinkFragment addDrinkFrag;
    public static SetProfileFragment setProfilefrag;

    Profile currentProfile;

    public static boolean  drinksCheck(){

        return drinks.isEmpty();

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainFrag = new BACCalculatorFragment();
        viewDrinksFrag = new ViewDrinksFragment();
        addDrinkFrag = new AddDrinkFragment();
        setProfilefrag = new SetProfileFragment();

        getSupportFragmentManager().beginTransaction()
                //MainFragmnet is the BAC MAin screen
                .add( R.id.mainContainer, mainFrag, "MainFragment")
                .commit();
    }

    @Override
    public void addDrinkToArray(Drink drink) {
        drinks.add(drink);

        BACCalculatorFragment temp= (BACCalculatorFragment) getSupportFragmentManager().findFragmentByTag("MainFragment");
        if(temp!=null){

            temp.drinksChange(drinks);
        }
        getSupportFragmentManager().popBackStack();
    }

    @Override
    public void profileInfo(Profile p) {
        currentProfile = p;
        BACCalculatorFragment temp= (BACCalculatorFragment) getSupportFragmentManager().findFragmentByTag("MainFragment");
        if(temp!=null){

            temp.update(currentProfile);

        }
        drinks.clear();
    }
}